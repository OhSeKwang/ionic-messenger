﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Test
{
    [XmlRoot("layout")]
    public class Layout
    {
        public Form myForm;
    }

    public class Form
    {

        [XmlAttribute("nm")]
        public String Name { get; set; }
        public List<Grid> myGrid { get; set; }
    }


    public class Grid
    {
        //[XmlElement("grid")]
        //[XmlAttribute("column")]
        public List<Column> myColumn { get; set; }
        [XmlAttribute("nm")]
        public string Name { get; set; }
    }

    public class Column
    {
        public string key { get; set; }

        public int order { get; set; }

        public int width { get; set; }


    }
}
