﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using Test;

namespace XmlSerialize
{
    public partial class Form1 : System.Windows.Forms.Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            XmlSerializer ser = new XmlSerializer(typeof(Layout));
            TextWriter writer = new StreamWriter("test.xml");

            Layout layout = new Layout();
            Test.Form form = new Test.Form();
            layout.myForm = form;
            form.Name = "Application1.Form1";

            form.myGrid = new List<Grid>();

            Grid grid1 = new Grid();
            grid1.Name = "grdSample";
            form.myGrid.Add(grid1);
            grid1.myColumn = new List<Column>();
            Column column1 = new Column();
            column1.key = "A";
            column1.order = 1;
            column1.width = 100;
            Column column2 = new Column();
            column2.key = "B";
            column2.order = 2;
            column2.width = 150;
            grid1.myColumn.Add(column1);
            grid1.myColumn.Add(column2);

            Grid grid2 = new Grid();
            grid2.Name = "grdSample2";
            form.myGrid.Add(grid2);
            grid2.myColumn = new List<Column>();
            Column column3 = new Column();
            column3.key = "C";
            column3.order = 3;
            column3.width = 200;
            Column column4 = new Column();
            column4.key = "D";
            column4.order = 4;
            column4.width = 250;

            grid2.myColumn.Add(column3);
            grid2.myColumn.Add(column4);

            ser.Serialize(writer, layout);
            writer.Close();
        }
    }
}
